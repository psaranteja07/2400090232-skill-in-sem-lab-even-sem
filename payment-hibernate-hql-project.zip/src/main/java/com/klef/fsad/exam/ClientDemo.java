
package com.klef.fsad.exam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class ClientDemo 
{
    public static void main(String[] args) 
    {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        cfg.addAnnotatedClass(Payment.class);

        SessionFactory sf = cfg.buildSessionFactory();
        Session session = sf.openSession();

        Transaction tx = session.beginTransaction();

        Payment p = new Payment(1,"Teja","12-03-2026","Success");
        session.save(p);

        tx.commit();
        System.out.println("Record Inserted");

        session.beginTransaction();

        Query q = session.createQuery("delete from Payment where id=:pid");
        q.setParameter("pid",1);

        int result = q.executeUpdate();

        session.getTransaction().commit();

        System.out.println("Deleted Records = "+result);

        session.close();
        sf.close();
    }
}
